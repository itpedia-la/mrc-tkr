-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2015 at 06:39 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `amlaocom_mrc-tkr`
--
CREATE DATABASE IF NOT EXISTS `amlaocom_mrc-tkr` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `amlaocom_mrc-tkr`;

-- --------------------------------------------------------

--
-- Table structure for table `application_log`
--

CREATE TABLE IF NOT EXISTS `application_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` varchar(145) DEFAULT NULL,
  `detail` varchar(45) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_transaction_log_user1_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(145) DEFAULT NULL,
  `telephone` varchar(145) DEFAULT NULL,
  `address` varchar(545) DEFAULT NULL,
  `seatJson` varchar(545) DEFAULT NULL COMMENT 'Store seat as json format',
  `total` int(11) DEFAULT NULL,
  `status` tinyint(5) DEFAULT NULL COMMENT '0 = Pending\n1 = Paid',
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `expired_at` datetime DEFAULT NULL,
  `remove` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customer_user1_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Triggers `customer`
--
DROP TRIGGER IF EXISTS `customer_BEFORE_INSERT`;
DELIMITER //
CREATE TRIGGER `customer_BEFORE_INSERT` BEFORE INSERT ON `customer`
 FOR EACH ROW BEGIN
    SET new.remove = 0 ;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `seat`
--

CREATE TABLE IF NOT EXISTS `seat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `row` varchar(45) DEFAULT NULL,
  `number` varchar(45) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `status` tinyint(5) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL COMMENT '0 = Available\n1 = Reserve\n2 = Close ( Paid )',
  `remove` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Triggers `seat`
--
DROP TRIGGER IF EXISTS `seat_BEFORE_INSERT`;
DELIMITER //
CREATE TRIGGER `seat_BEFORE_INSERT` BEFORE INSERT ON `seat`
 FOR EACH ROW BEGIN
    SET new.remove = 0;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_group_id` int(11) NOT NULL,
  `login` varchar(145) NOT NULL,
  `password` varchar(145) NOT NULL,
  `firstname` varchar(145) NOT NULL,
  `lastname` varchar(145) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `systemUser` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `remove` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_user_group1_idx` (`user_group_id`),
  KEY `login` (`login`),
  KEY `password` (`password`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_group_id`, `login`, `password`, `firstname`, `lastname`, `remember_token`, `systemUser`, `created_at`, `updated_at`, `remove`) VALUES
(2, 1, 'dsouksavatd@gmail.com', '$2y$10$cNiaCpZ5JTq47YKTAJXB4.s8uTza4Jfoqh/0QhFD64F45hqXu.doW', 'Somwang', 'Souksavatd', 'xIwYwwTXOwAgZkZYn2Df9tC90IKxrClc92bw9MNRQy2LGRJCsGiqJU1GclmW', 1, '2015-01-21 00:00:00', '2015-01-21 17:14:54', 0),
(3, 3, 'abcde', '$2y$10$kEdPFRtbusTQEL5MqP3ZMO4EEDKg5TL3kf/qjWMu18VxpKKvSO/Fq', 'Silaphet', 'Inthavong', NULL, 0, '2015-01-21 17:05:54', '2015-01-21 17:05:54', 0);

--
-- Triggers `user`
--
DROP TRIGGER IF EXISTS `user_BEFORE_INSERT`;
DELIMITER //
CREATE TRIGGER `user_BEFORE_INSERT` BEFORE INSERT ON `user`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
BEGIN
SET new.remove = 0;
SET new.systemUser = 0;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(145) NOT NULL,
  `permissionList` text,
  `invisible` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_group`
--

INSERT INTO `user_group` (`id`, `name`, `permissionList`, `invisible`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', NULL, 1, '2015-01-21 00:00:00', '2015-01-21 00:00:00'),
(2, 'ຜູ້ຈັດການ', '{"1":"\\u0ec0\\u0e9e\\u0eb5\\u0ec8\\u0ea1\\u0e9c\\u0eb9\\u0ec9\\u0ec3\\u0e8a\\u0ec9\\u0e87\\u0eb2\\u0e99 ( User Add )","2":"\\u0ea5\\u0ebb\\u0e9a\\u0ea5\\u0ec9\\u0eb2\\u0e87 ( User Remove )","3":"\\u0eaa\\u0eb0\\u0ec1\\u0e94\\u0e87\\u0ea5\\u0eb2\\u0e8d\\u0e81\\u0eb2\\u0e99 ( User List )","5":"\\u0eaa\\u0eb0\\u0ec1\\u0e94\\u0e87\\u0ea5\\u0eb2\\u0e8d\\u0e81\\u0eb2\\u0e99\\u0ec1\\u0e9c\\u0e99\\u0e9c\\u0eb1\\u0e87","6":"\\u0e88\\u0ead\\u0e87 \\u0ec1\\u0ea5\\u0eb0 \\u0e82\\u0eb2\\u0e8d\\u0e9a\\u0ec8\\u0ead\\u0e99\\u0e99\\u0eb1\\u0ec8\\u0e87","7":"\\u0ec1\\u0e81\\u0ec9\\u0ec4\\u0e82\\u0e81\\u0eb2\\u0e99 \\u0e88\\u0ead\\u0e87 \\u0ec1\\u0ea5\\u0eb0 \\u0e82\\u0eb2\\u0e8d\\u0e9a\\u0ec8\\u0ead\\u0e99\\u0e99\\u0eb1\\u0ec8\\u0e87","8":"\\u0ea5\\u0ebb\\u0e9a\\u0ea5\\u0ec9\\u0eb2\\u0e87\\u0e81\\u0eb2\\u0e99 \\u0e88\\u0ead\\u0e87 \\u0ec1\\u0ea5\\u0eb0 \\u0e82\\u0eb2\\u0e8d\\u0e9a\\u0ec8\\u0ead\\u0e99\\u0e99\\u0eb1\\u0ec8\\u0e87"}', 0, '2015-01-21 00:00:00', '2015-01-21 17:06:10'),
(3, 'ຝ່າຍຂາຍ', '{"5":"\\u0eaa\\u0eb0\\u0ec1\\u0e94\\u0e87\\u0ea5\\u0eb2\\u0e8d\\u0e81\\u0eb2\\u0e99\\u0ec1\\u0e9c\\u0e99\\u0e9c\\u0eb1\\u0e87","6":"\\u0e88\\u0ead\\u0e87 \\u0ec1\\u0ea5\\u0eb0 \\u0e82\\u0eb2\\u0e8d\\u0e9a\\u0ec8\\u0ead\\u0e99\\u0e99\\u0eb1\\u0ec8\\u0e87"}', 0, '2015-01-21 00:00:00', '2015-01-21 17:06:23');

--
-- Triggers `user_group`
--
DROP TRIGGER IF EXISTS `user_group_BINS`;
DELIMITER //
CREATE TRIGGER `user_group_BINS` BEFORE INSERT ON `user_group`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
BEGIN
SET new.invisible = 0;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_group_permission`
--

CREATE TABLE IF NOT EXISTS `user_group_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionZone` varchar(145) NOT NULL,
  `permissionTitle` varchar(145) NOT NULL,
  `permissionDescription` varchar(245) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `user_group_permission`
--

INSERT INTO `user_group_permission` (`id`, `permissionZone`, `permissionTitle`, `permissionDescription`) VALUES
(1, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ເພີ່ມຜູ້ໃຊ້ງານ ( User Add )', 'ອະນຸຍາດໃນການເພີ່ມຜູ້ໃຊ້ງານ'),
(2, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ລົບລ້າງ ( User Remove )', 'ອະນຸຍາດໃຫ້ລົບລ້າງຜູ້ໃຊ້ງານ'),
(3, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ສະແດງລາຍການ ( User List )', 'ອະນຸຍາດໃຫ້ສະແດງລາຍການຜູ້ໃຊ້ງານ'),
(4, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ແກ້ໄຂລະຫັດຜ່ານ ( Change User Password )', 'ອະນຸຍາດໃຫ້ແກ້ໄຂລະຫັດຜ່ານຂອງຜູ້ໃຊ້ງານ'),
(5, 'ການຈອງ ແລະ ການຂາຍປີ້', 'ສະແດງລາຍການແຜນຜັງ', 'ອະນຸຍາດໃຫ້ສະແດງລາຍການແຜນຜັງ'),
(6, 'ການຈອງ ແລະ ການຂາຍປີ້', 'ຈອງ ແລະ ຂາຍບ່ອນນັ່ງ', 'ອະນຸຍາໃຫ້ ຈອງ ແລະ ຂາຍບ່ອນນັ່ງ'),
(7, 'ການຈອງ ແລະ ການຂາຍປີ້', 'ແກ້ໄຂການ ຈອງ ແລະ ຂາຍບ່ອນນັ່ງ', 'ອະນຸຍາໃຫ້ແກ້ໄຂການ ຈອງ ແລະ ຂາຍບ່ອນນັ່ງ'),
(8, 'ການຈອງ ແລະ ການຂາຍປີ້', 'ລົບລ້າງການ ຈອງ ແລະ ຂາຍບ່ອນນັ່ງ', 'ອະນຸຍາໃຫ້ລົບລ້າງການ ຈອງ ແລະ ຂາຍບ່ອນນັ່ງ');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `application_log`
--
ALTER TABLE `application_log`
  ADD CONSTRAINT `fk_transaction_log_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `fk_customer_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_user_group1` FOREIGN KEY (`user_group_id`) REFERENCES `user_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
